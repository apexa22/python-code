# -*- coding: utf-8 -*-
"""
Created on Sat Jul 10 12:23:59 2021

@author: Lenovo
"""

# import string library function 
import string 
    
# Storing the value in variable result 
result = string.ascii_uppercase 
    
# Printing the value 
print(result) 